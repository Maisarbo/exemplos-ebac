package br.com.maisa.entities;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PortifolioWebApplicationTests {

	@Test
	void contextLoads() {
	}

}
